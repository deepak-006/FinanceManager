package com.example.first;

public class ModelClass {
    public String date;
    public String data;
    public int amount;

    public ModelClass(String date, int amount, String data) {
        this.date = date;
        this.amount = amount;
        this.data = data;
    }
}
