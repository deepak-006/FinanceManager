package com.example.first;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class ChartActivity extends AppCompatActivity {

    BarChart barChart;
    public static final String SHARED_PREFS1 = "sharedPrefs1";
    public static final String TEXT1 = "text1";
    ArrayList<ModelClass> arrayList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        barChart = findViewById(R.id.bar_chart);

        ArrayList<BarEntry> barEntries = new ArrayList<>();

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("DATA7",MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("dates7", null);
        Type type = new TypeToken<ArrayList<ModelClass>>(){}.getType();
        arrayList = gson.fromJson(json,type);

        for (int i = 1;i<arrayList.size();i++){

            BarEntry barEntry =  new BarEntry(i, arrayList.get(i).amount);
            barEntries.add(barEntry);
        }
        BarDataSet barDataSet = new BarDataSet(barEntries,"Spending");
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        barDataSet.setDrawValues(false);
        barChart.setData(new BarData(barDataSet));
        barChart.getDescription().setText("Spending Data");


    }

}